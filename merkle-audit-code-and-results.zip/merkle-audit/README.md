# Merkle-tree public auditing for S3 object storage — prototype and experiments

Code, contract, raw results and figure scripts for the paper
"Merkle-Tree-Based Verifiable Public Data Auditing for Cloud Object Storage Using Smart Contracts".

## Layout
- `merkle_audit/merkle.py` — SHA-256 leaves (key-bound, 0x00 prefix), internal nodes (0x01 prefix), promotion of unpaired nodes, proofs, verification
- `merkle_audit/audit.py` — owner commitment, prover, public audit (intact / modified / missing), full-data baseline
- `merkle_audit/storage.py` — S3 client wrapper (MinIO Python SDK)
- `merkle_audit/chain.py` — Web3.py interface to the contract
- `chain/contracts/MerkleAuditRegistry.sol` — registry (registerRoot, getRoot, recordAudit, verifyProof) + per-object-hash baseline
- `chain/compile.js` — compiles with solc-js 0.8.24 to `chain/build.json`
- `experiments.py` — all experiments (E1–E5, in-memory benchmark, smart-contract evaluation) → `results/*.json`
- `plots.py` — every figure from `results/*.json` → `figures/*.pdf`
- `tests/` — pytest unit tests and Solidity/Python cross-check
- `s3s-fs-nodelay.patch` — one-line TCP_NODELAY patch applied to s3s-fs 0.17.0 (see paper, Section VI)

## Reproduce
```bash
pip install web3==8.0.0 minio==7.2.20 matplotlib psutil pytest
cd chain && npm install solc@0.8.24 hardhat@2.22.17 && node compile.js && npx hardhat node --port 8545 &
cd ..
# any S3-compatible server on 127.0.0.1:9000, access key "audit", secret "audit-secret-key", e.g.
#   minio server /data --address 127.0.0.1:9000   (MINIO_ROOT_USER=audit MINIO_ROOT_PASSWORD=audit-secret-key)
#   or the patched s3s-fs used in the paper:
#   s3s-fs --host 127.0.0.1 --port 9000 --access-key audit --secret-key audit-secret-key /data
python3 -m pytest -q tests
python3 experiments.py all      # ~20 min on 2 vCPU
python3 plots.py
```
Note: object keys are flat (no "/"); listing uses a delimiter, which s3s-fs requires.
