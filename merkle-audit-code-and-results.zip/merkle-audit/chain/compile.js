// Compiles the contract with solc-js 0.8.24 (optimizer on, 200 runs) and writes ABI + bytecode.
const fs = require('fs'); const solc = require('solc');
const src = fs.readFileSync('contracts/MerkleAuditRegistry.sol', 'utf8');
const input = { language: 'Solidity', sources: { 'MerkleAuditRegistry.sol': { content: src } },
  settings: { optimizer: { enabled: true, runs: 200 }, evmVersion: 'cancun',
    outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object'] } } } };
const out = JSON.parse(solc.compile(JSON.stringify(input)));
if (out.errors) { for (const e of out.errors) console.error(e.formattedMessage); if (out.errors.some(e => e.severity === 'error')) process.exit(1); }
const res = {}; for (const [n, c] of Object.entries(out.contracts['MerkleAuditRegistry.sol']))
  res[n] = { abi: c.abi, bytecode: '0x' + c.evm.bytecode.object, deployedSize: c.evm.deployedBytecode.object.length / 2 };
res._compiler = solc.version();
fs.writeFileSync('build.json', JSON.stringify(res, null, 1)); console.log('compiled with', solc.version());
for (const n of Object.keys(res)) if (n[0] !== '_') console.log(n, 'deployed bytes', res[n].deployedSize);
