// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title MerkleAuditRegistry
/// @notice Stores the trusted Merkle root of an off-chain object-storage dataset
///         and an append-only log of audit outcomes. No object data is stored on-chain.
contract MerkleAuditRegistry {
    struct Dataset {
        bytes32 root;          // trusted Merkle root (SHA-256)
        uint64 leafCount;      // number of objects committed by the root
        uint64 registeredAt;   // block timestamp of the latest registration
        uint32 version;        // incremented on every re-registration
        address owner;         // data owner allowed to (re)register
    }

    struct AuditRecord {
        bytes32 rootAtAudit;   // trusted root the audit was checked against
        uint64 timestamp;
        uint32 checked;        // objects checked in this audit
        uint32 failed;         // objects classified as modified or missing
        bool passed;
        address auditor;
    }

    mapping(bytes32 => Dataset) private datasets;
    mapping(bytes32 => AuditRecord[]) private audits;

    event RootRegistered(bytes32 indexed datasetId, bytes32 root, uint64 leafCount, uint32 version);
    event AuditRecorded(bytes32 indexed datasetId, uint256 index, bool passed, uint32 checked, uint32 failed);

    /// @notice Register (or re-register) the trusted root of a dataset.
    function registerRoot(bytes32 datasetId, bytes32 root, uint64 leafCount) external {
        Dataset storage d = datasets[datasetId];
        require(d.owner == address(0) || d.owner == msg.sender, "not dataset owner");
        require(root != bytes32(0) && leafCount > 0, "invalid commitment");
        d.root = root;
        d.leafCount = leafCount;
        d.registeredAt = uint64(block.timestamp);
        d.version += 1;
        d.owner = msg.sender;
        emit RootRegistered(datasetId, root, leafCount, d.version);
    }

    /// @notice Read the trusted commitment of a dataset.
    function getRoot(bytes32 datasetId)
        external view
        returns (bytes32 root, uint64 leafCount, uint64 registeredAt, uint32 version, address owner)
    {
        Dataset storage d = datasets[datasetId];
        require(d.owner != address(0), "unknown dataset");
        return (d.root, d.leafCount, d.registeredAt, d.version, d.owner);
    }

    /// @notice Append the outcome of an off-chain audit to the public log.
    function recordAudit(bytes32 datasetId, uint32 checked, uint32 failed) external {
        Dataset storage d = datasets[datasetId];
        require(d.owner != address(0), "unknown dataset");
        bool passed = (failed == 0);
        audits[datasetId].push(AuditRecord(d.root, uint64(block.timestamp), checked, failed, passed, msg.sender));
        emit AuditRecorded(datasetId, audits[datasetId].length - 1, passed, checked, failed);
    }

    function auditCount(bytes32 datasetId) external view returns (uint256) {
        return audits[datasetId].length;
    }

    function getAudit(bytes32 datasetId, uint256 index) external view returns (AuditRecord memory) {
        return audits[datasetId][index];
    }

    /// @notice Verify a Merkle proof on-chain against the registered root.
    /// @param leaf      leaf node hash  SHA256(0x00 || SHA256(key) || SHA256(content))
    /// @param siblings  sibling hashes from leaf level upwards
    /// @param leftMask  bit j = 1 if siblings[j] is the LEFT child at step j
    function verifyProof(bytes32 datasetId, bytes32 leaf, bytes32[] calldata siblings, uint256 leftMask)
        external view returns (bool)
    {
        bytes32 h = leaf;
        for (uint256 j = 0; j < siblings.length; j++) {
            if ((leftMask >> j) & 1 == 1) {
                h = sha256(abi.encodePacked(bytes1(0x01), siblings[j], h));
            } else {
                h = sha256(abi.encodePacked(bytes1(0x01), h, siblings[j]));
            }
        }
        return h == datasets[datasetId].root;
    }
}

/// @notice Baseline used only in the evaluation: stores every object digest on-chain.
contract PerObjectHashRegistry {
    mapping(bytes32 => mapping(uint256 => bytes32)) public digests;

    function storeBatch(bytes32 datasetId, uint256 startIndex, bytes32[] calldata hashes) external {
        for (uint256 i = 0; i < hashes.length; i++) {
            digests[datasetId][startIndex + i] = hashes[i];
        }
    }
}
