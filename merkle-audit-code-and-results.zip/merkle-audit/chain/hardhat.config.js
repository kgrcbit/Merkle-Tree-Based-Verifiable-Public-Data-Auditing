module.exports = {
  networks: { hardhat: { chainId: 31337, hardfork: "cancun", blockGasLimit: 30000000,
    mining: { auto: true, interval: 0 } } },
};
