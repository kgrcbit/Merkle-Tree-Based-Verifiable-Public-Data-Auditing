"""Runs every experiment of the paper and writes raw results to results/*.json.

Usage: python3 experiments.py [all|env|e1|e2|e3|e4|e5|mem|comm|sc]
Requires: S3-compatible server on 127.0.0.1:9000 and an Ethereum JSON-RPC node on 127.0.0.1:8545.
"""
from __future__ import annotations

import gc
import json
import math
import os
import platform
import random
import statistics as st
import subprocess
import sys
import time
import tracemalloc

import psutil

from merkle_audit.audit import (INTACT, MISSING, MODIFIED, Prover, build_commitment, full_data_baseline,
                                full_root_audit, proof_audit, sample_indices)
from merkle_audit.chain import Registry
from merkle_audit.merkle import MerkleTree, content_digest, leaf_hash, root_from_proof
from merkle_audit.storage import ObjectStore

OUT = os.path.join(os.path.dirname(__file__), "results")
os.makedirs(OUT, exist_ok=True)
REPS = 5
SEED = 2026
MIN_SIZE, MAX_SIZE = 1024, 256 * 1024          # log-uniform object sizes, 1 KiB .. 256 KiB
PRIMARY_N = 1000                              # dataset used by E1-E4


def save(name, obj):
    with open(os.path.join(OUT, f"{name}.json"), "w") as f:
        json.dump(obj, f, indent=1)
    print(f"[saved] results/{name}.json")


def object_size(n_seed: int, i: int) -> int:
    r = random.Random(n_seed * 1_000_003 + i)
    return int(math.exp(r.uniform(math.log(MIN_SIZE), math.log(MAX_SIZE))))


def object_bytes(n_seed: int, i: int) -> bytes:
    r = random.Random(n_seed * 7_000_001 + i)
    return r.randbytes(object_size(n_seed, i))


def key_of(i: int) -> str:
    return f"obj-{i:07d}.bin"


def upload_dataset(store, bucket, n, keep=False):
    store.reset_bucket(bucket)
    contents = {}
    total = 0
    t0 = time.perf_counter()
    for i in range(n):
        d = object_bytes(n, i)
        store.put(bucket, key_of(i), d)
        total += len(d)
        if keep:
            contents[key_of(i)] = d
    return contents, total, time.perf_counter() - t0


def summary(xs):
    xs = list(xs)
    return {"mean": st.mean(xs), "std": st.stdev(xs) if len(xs) > 1 else 0.0,
            "min": min(xs), "max": max(xs), "runs": xs}


def report_dict(rep):
    return {"checked": rep.checked, "intact": rep.count(INTACT), "modified": rep.count(MODIFIED),
            "missing": rep.count(MISSING), "passed": rep.passed, "bytes_objects": rep.bytes_objects,
            "bytes_proofs": rep.bytes_proofs, "t_chain": rep.t_chain, "t_fetch": rep.t_fetch,
            "t_hash": rep.t_hash, "t_proofgen": rep.t_proofgen, "t_verify": rep.t_verify,
            "t_total": rep.t_total}


def tamper_bytes(d: bytes, mode: str, rng: random.Random) -> bytes:
    if mode == "bitflip":
        b = bytearray(d)
        pos = rng.randrange(len(b))
        b[pos] ^= 1 << rng.randrange(8)
        return bytes(b)
    if mode == "append":
        return d + b"\x00"
    if mode == "replace":
        return rng.randbytes(len(d))
    raise ValueError(mode)


class Ctx:
    def __init__(self):
        self.store = ObjectStore()
        self.reg = Registry()
        self.reg.deploy()

    def setup_trusted(self, bucket, n, keep=True):
        contents, total, t_up = upload_dataset(self.store, bucket, n, keep=keep)
        com = build_commitment(self.store, bucket, keys=[key_of(i) for i in range(n)],
                               contents=contents if keep else None)
        ds = self.reg.dataset_id(f"{bucket}-{n}-{time.time_ns()}")
        tx = self.reg.register_root(ds, com.root, n)
        return contents, total, t_up, com, ds, tx

    def audit_all(self, bucket, com, ds):
        root, n, ver, t_chain = self.reg.get_root(ds)
        return proof_audit(self.store, bucket, Prover(com), root, n, list(range(n)), t_chain)


# ----------------------------------------------------------------------------------- environment
def env():
    def run(cmd, cwd=None):
        try:
            return subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd).stdout.strip()
        except Exception as e:  # pragma: no cover
            return str(e)
    import minio, web3
    build = json.load(open("chain/build.json"))
    info = {
        "cpu": run("lscpu | grep 'Model name' | sed 's/Model name: *//'"),
        "vcpus": os.cpu_count(), "ram_gib": round(psutil.virtual_memory().total / 2**30, 1),
        "os": run(". /etc/os-release && echo $PRETTY_NAME") + " / kernel " + platform.release(),
        "python": platform.python_version(), "minio_sdk": minio.__version__, "web3": web3.__version__,
        "solc": build["_compiler"], "hardhat": run("npx hardhat --version", cwd="chain"),
        "node": run("node --version"), "s3_server": run("s3srv/bin/s3s-fs --version"),
        "registry_deployed_bytes": build["MerkleAuditRegistry"]["deployedSize"],
        "fs": run("df -T /home/claude | tail -1 | awk '{print $2}'"),
    }
    save("env", info)
    print(info)


# ----------------------------------------------------------------------------------- E1 normal audit
def e1(ctx: Ctx):
    n, bucket = PRIMARY_N, "e1-normal"
    contents, total, t_up, com, ds, tx = ctx.setup_trusted(bucket, n)
    runs = []
    for r in range(REPS):
        gc.collect()
        rep = ctx.audit_all(bucket, com, ds)
        ok, root, missing, nbytes, t_root = full_root_audit(ctx.store, bucket, com.keys, com.root)
        runs.append({**report_dict(rep), "root_audit_ok": ok, "t_root_audit": t_root})
    rec = ctx.reg.record_audit(ds, n, 0)
    sizes = [len(v) for v in contents.values()]
    save("e1", {
        "n": n, "total_bytes": total, "mean_obj": st.mean(sizes), "t_upload": t_up,
        "commit": {"t_hash": com.t_hash, "t_build": com.t_build, "root": com.root.hex(),
                   "metadata_bytes": com.metadata_bytes(), "nodes": com.tree.node_count(),
                   "depth": len(com.tree.levels) - 1},
        "register": vars(tx), "record_audit": vars(rec), "runs": runs,
    })


# ----------------------------------------------------------------------------------- E2 single tamper
def e2(ctx: Ctx):
    n, bucket = PRIMARY_N, "e2-single"
    contents, total, t_up, com, ds, _ = ctx.setup_trusted(bucket, n)
    out = {"n": n, "trusted_root": com.root.hex(), "modes": {}}
    rng = random.Random(SEED)
    for mode in ("bitflip", "append", "replace"):
        runs = []
        for r in range(REPS):
            idx = rng.randrange(n)
            key = com.keys[idx]
            orig = contents[key]
            bad = tamper_bytes(orig, mode, rng)
            ctx.store.put(bucket, key, bad)
            # targeted single-object audit (detection time)
            root, cnt, ver, t_chain = ctx.reg.get_root(ds)
            t0 = time.perf_counter()
            one = proof_audit(ctx.store, bucket, Prover(com), root, cnt, [idx], t_chain)
            t_detect = time.perf_counter() - t0 + t_chain
            # full localisation audit
            full = ctx.audit_all(bucket, com, ds)
            ok_root, comp_root, _, _, t_root = full_root_audit(ctx.store, bucket, com.keys, com.root)
            leaf_new = leaf_hash(key, content_digest(bad))
            path_root = root_from_proof(leaf_new, com.tree.proof(idx))
            runs.append({
                "index": idx, "key": key, "orig_size": len(orig), "new_size": len(bad),
                "orig_digest": content_digest(orig).hex(), "new_digest": content_digest(bad).hex(),
                "path_root": path_root.hex(), "full_recomputed_root": comp_root.hex(),
                "single": report_dict(one), "t_detect": t_detect, "full": report_dict(full),
                "full_flagged": full.failed, "root_audit_ok": ok_root, "t_root_audit": t_root,
                "proof_len": len(com.tree.proof(idx).siblings),
            })
            ctx.store.put(bucket, key, orig)          # restore trusted state
        out["modes"][mode] = runs
    save("e2", out)


# ----------------------------------------------------------------------------------- E3 multiple tamper
def detection_prob(n, t, c):
    if c > n - t:
        return 1.0
    return 1.0 - math.exp(math.lgamma(n - t + 1) - math.lgamma(n - t - c + 1)
                          - math.lgamma(n + 1) + math.lgamma(n - c + 1))


def e3(ctx: Ctx):
    n, bucket = PRIMARY_N, "e3-multi"
    contents, total, t_up, com, ds, _ = ctx.setup_trusted(bucket, n)
    levels = [1, 5, 10, 25, 50, 100, 250]
    samples = [10, 50, 100, 300]
    trials = 2000
    rng = random.Random(SEED + 3)
    out = {"n": n, "levels": {}, "samples": samples, "trials": trials}
    for t in levels:
        runs = []
        for r in range(REPS):
            idxs = sorted(rng.sample(range(n), t))
            truth = {com.keys[i] for i in idxs}
            for i in idxs:
                ctx.store.put(bucket, com.keys[i], tamper_bytes(contents[com.keys[i]], "bitflip", rng))
            full = ctx.audit_all(bucket, com, ds)
            flagged = set(full.failed)
            # sampled audits: real runs (timing) for each c
            sampled = {}
            for c in samples:
                root, cnt, ver, t_chain = ctx.reg.get_root(ds)
                srep = proof_audit(ctx.store, bucket, Prover(com), root, cnt, sample_indices(n, c, rng), t_chain)
                sampled[c] = {"t_total": srep.t_total, "detected": not srep.passed,
                              "bytes": srep.bytes_objects + srep.bytes_proofs}
            # Monte Carlo over the measured per-object outcomes of this tampered state
            failed_idx = {i for i, k in enumerate(com.keys) if full.status[k] != INTACT}
            mc = {}
            for c in samples:
                hits = sum(1 for _ in range(trials) if failed_idx.intersection(rng.sample(range(n), c)))
                mc[c] = hits / trials
            runs.append({**report_dict(full), "true_pos": len(flagged & truth),
                         "false_pos": len(flagged - truth), "false_neg": len(truth - flagged),
                         "sampled": sampled, "mc_detect": mc})
            for i in idxs:
                ctx.store.put(bucket, com.keys[i], contents[com.keys[i]])
        out["levels"][t] = {"runs": runs, "analytic": {c: detection_prob(n, t, c) for c in samples}}
        print(f"E3 t={t}: tp={[x['true_pos'] for x in runs]} fp={[x['false_pos'] for x in runs]}")
    save("e3", out)


# ----------------------------------------------------------------------------------- E4 deletion
def e4(ctx: Ctx):
    n, bucket = PRIMARY_N, "e4-delete"
    contents, total, t_up, com, ds, _ = ctx.setup_trusted(bucket, n)
    rng = random.Random(SEED + 4)
    out = {"n": n, "levels": {}, "mixed": []}
    for d in [1, 5, 10, 50, 100]:
        runs = []
        for r in range(REPS):
            idxs = sorted(rng.sample(range(n), d))
            truth = {com.keys[i] for i in idxs}
            for i in idxs:
                ctx.store.delete(bucket, com.keys[i])
            root, cnt, ver, t_chain = ctx.reg.get_root(ds)
            t0 = time.perf_counter()
            one = proof_audit(ctx.store, bucket, Prover(com), root, cnt, [idxs[0]], t_chain)
            t_detect = time.perf_counter() - t0 + t_chain
            full = ctx.audit_all(bucket, com, ds)
            ok_root, _, missing, _, t_root = full_root_audit(ctx.store, bucket, com.keys, com.root)
            listed = len(ctx.store.list_keys(bucket))
            missing_found = {k for k, s in full.status.items() if s == MISSING}
            runs.append({**report_dict(full), "t_detect": t_detect, "single_status": list(one.status.values())[0],
                         "true_missing": len(missing_found & truth), "false_missing": len(missing_found - truth),
                         "root_audit_ok": ok_root, "t_root_audit": t_root, "listed_after": listed})
            for i in idxs:
                ctx.store.put(bucket, com.keys[i], contents[com.keys[i]])
        out["levels"][d] = runs
        print(f"E4 d={d}: missing={[x['missing'] for x in runs]} modified={[x['modified'] for x in runs]}")
    # mixed: 20 modified + 20 deleted, three-way classification
    for r in range(REPS):
        idxs = rng.sample(range(n), 40)
        mod, dele = set(idxs[:20]), set(idxs[20:])
        for i in mod:
            ctx.store.put(bucket, com.keys[i], tamper_bytes(contents[com.keys[i]], "bitflip", rng))
        for i in dele:
            ctx.store.delete(bucket, com.keys[i])
        full = ctx.audit_all(bucket, com, ds)
        conf = {}
        for i, k in enumerate(com.keys):
            truth = MODIFIED if i in mod else MISSING if i in dele else INTACT
            conf[f"{truth}->{full.status[k]}"] = conf.get(f"{truth}->{full.status[k]}", 0) + 1
        out["mixed"].append({"confusion": conf, **report_dict(full)})
        for i in mod | dele:
            ctx.store.put(bucket, com.keys[i], contents[com.keys[i]])
    save("e4", out)


# ----------------------------------------------------------------------------------- E5 scalability (S3)
def e5(ctx: Ctx):
    out = {}
    for n in [10, 100, 1000, 10000]:
        bucket = f"e5-n{n}"
        _, total, t_up = upload_dataset(ctx.store, bucket, n, keep=False)
        keys = [key_of(i) for i in range(n)]
        commits, audits, roots, singles, sampled, baselines = [], [], [], [], [], []
        mem_peak = None
        reps = REPS if n <= 1000 else 3
        for r in range(reps):
            gc.collect()
            # owner commitment: read back from store, hash, build (tracemalloc only on first run)
            if r == 0:
                tracemalloc.start()
            com = build_commitment(ctx.store, bucket, keys=keys)
            if r == 0:
                _, mem_peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                com = build_commitment(ctx.store, bucket, keys=keys)   # timed run without tracing
            commits.append({"t_fetch": com.t_fetch, "t_hash": com.t_hash, "t_build": com.t_build})
            if r == 0:
                ds = ctx.reg.dataset_id(f"{bucket}-{time.time_ns()}")
                tx = ctx.reg.register_root(ds, com.root, n)
            root, cnt, ver, t_chain = ctx.reg.get_root(ds)
            rep = proof_audit(ctx.store, bucket, Prover(com), root, cnt, list(range(n)), t_chain)
            assert rep.passed
            audits.append(report_dict(rep))
            ok, _, _, nbytes, t_root = full_root_audit(ctx.store, bucket, keys, com.root)
            assert ok
            roots.append(t_root)
            rng = random.Random(SEED + r)
            one = proof_audit(ctx.store, bucket, Prover(com), root, cnt, [rng.randrange(n)], t_chain)
            singles.append(report_dict(one))
            c = min(100, n)
            s = proof_audit(ctx.store, bucket, Prover(com), root, cnt, sample_indices(n, c, rng), t_chain)
            sampled.append(report_dict(s))
            digests = {k: content_digest(ctx.store.get(bucket, k)) for k in keys} if r == 0 else digests
            status, b_bytes, b_fetch, b_hash, b_total = full_data_baseline(ctx.store, bucket, keys, digests)
            baselines.append({"bytes": b_bytes, "t_fetch": b_fetch, "t_hash": b_hash, "t_total": b_total})
        proof_lens = [len(com.tree.proof(i).siblings) for i in range(n)]
        out[n] = {"total_bytes": total, "t_upload": t_up, "reps": reps, "commits": commits, "audits": audits,
                  "root_audit": roots, "single": singles, "sampled": sampled, "baseline": baselines,
                  "mem_peak_commit": mem_peak, "metadata_bytes": com.metadata_bytes(),
                  "proof_len_max": max(proof_lens), "proof_len_mean": st.mean(proof_lens),
                  "register_gas": tx.gas_used, "rss_mib": psutil.Process().memory_info().rss / 2**20}
        print(f"E5 n={n}: build={st.mean(x['t_build'] for x in commits):.4f}s "
              f"audit={st.mean(a['t_total'] for a in audits):.2f}s")
        ctx.store.reset_bucket(bucket)  # free disk
    save("e5", out)


# ----------------------------------------------------------------------------------- in-memory Merkle micro-benchmark
def mem():
    out = {}
    for exp in range(4, 21, 2):          # 16 .. 1,048,576 leaves
        n = 2 ** exp
        rng = random.Random(SEED + exp)
        leaves = [leaf_hash(key_of(i), rng.randbytes(32)) for i in range(n)]
        builds, gens, vers = [], [], []
        mpeak = None
        for r in range(REPS):
            gc.collect()
            if r == 0:
                tracemalloc.start()
                t = MerkleTree(leaves)
                mpeak = tracemalloc.get_traced_memory()[1]
                tracemalloc.stop()
                del t
                gc.collect()
            t0 = time.perf_counter()
            tree = MerkleTree(leaves)
            builds.append(time.perf_counter() - t0)
            idx = [rng.randrange(n) for _ in range(1000)]
            t0 = time.perf_counter()
            proofs = [tree.proof(i) for i in idx]
            gens.append((time.perf_counter() - t0) / len(idx))
            t0 = time.perf_counter()
            okc = sum(root_from_proof(leaves[i], p) == tree.root for i, p in zip(idx, proofs))
            vers.append((time.perf_counter() - t0) / len(idx))
            assert okc == len(idx)
        plen = len(tree.proof(n - 1).siblings)
        out[n] = {"build": summary(builds), "proofgen": summary(gens), "verify": summary(vers),
                  "mem_peak": mpeak, "proof_len": plen, "proof_bytes": 32 * plen + 32,
                  "nodes": tree.node_count()}
        print(f"mem n={n}: build={st.mean(builds):.4f}s gen={st.mean(gens)*1e6:.1f}us ver={st.mean(vers)*1e6:.1f}us")
        del tree, leaves
    save("mem", out)


# ----------------------------------------------------------------------------------- smart-contract evaluation
def sc():
    reg = Registry()
    out = {}
    _, dep = reg.deploy()
    out["deploy"] = vars(dep)
    base, dep2 = reg.deploy("PerObjectHashRegistry")
    out["deploy_baseline"] = vars(dep2)
    rng = random.Random(SEED)
    reg_first, reg_update, rec_first, rec_next, get_gas, get_lat = [], [], [], [], [], []
    for r in range(REPS):
        ds = reg.dataset_id(f"sc-{r}-{time.time_ns()}")
        reg_first.append(vars(reg.register_root(ds, rng.randbytes(32), 1000)))
        reg_update.append(vars(reg.register_root(ds, rng.randbytes(32), 1000)))
        rec_first.append(vars(reg.record_audit(ds, 1000, 0)))
        rec_next.append(vars(reg.record_audit(ds, 1000, 3)))
        get_gas.append(reg.get_root_gas(ds))
        get_lat.append(reg.get_root(ds)[3])
    out.update({"register_first": reg_first, "register_update": reg_update, "record_first": rec_first,
                "record_next": rec_next, "get_gas": get_gas, "get_latency": get_lat})
    # on-chain proof verification cost vs tree size
    ver = {}
    for exp in [1, 4, 7, 10, 14, 17, 20]:
        n = 2 ** exp
        leaves = [leaf_hash(key_of(i), rng.randbytes(32)) for i in range(n)]
        tree = MerkleTree(leaves)
        ds = reg.dataset_id(f"ver-{n}-{time.time_ns()}")
        reg.register_root(ds, tree.root, n)
        rows = []
        for _ in range(REPS):
            i = rng.randrange(n)
            p = tree.proof(i)
            ok, gas, dt = reg.verify_onchain(ds, leaves[i], p.siblings, p.left_mask)
            assert ok
            rows.append({"gas": gas, "latency": dt, "proof_len": len(p.siblings)})
        ver[n] = rows
        print(f"sc verify n={n}: gas={rows[0]['gas']} len={rows[0]['proof_len']}")
    out["verify"] = ver
    # baseline: every object digest on-chain (batches of 100)
    bl = {}
    for n in [10, 100, 1000]:
        ds = reg.dataset_id(f"bl-{n}-{time.time_ns()}")
        gas = 0
        txs = 0
        lat = 0.0
        for s in range(0, n, 100):
            batch = [rng.randbytes(32) for _ in range(min(100, n - s))]
            fn = base.functions.storeBatch(ds, s, batch)
            t = fn.build_transaction({"from": reg.owner})
            t0 = time.perf_counter()
            rc = reg.w3.eth.wait_for_transaction_receipt(reg.w3.eth.send_transaction(t))
            lat += time.perf_counter() - t0
            gas += rc.gasUsed
            txs += 1
        bl[n] = {"gas": gas, "txs": txs, "latency": lat, "storage_bytes": 32 * n}
        print(f"baseline n={n}: gas={gas} txs={txs}")
    out["baseline"] = bl
    save("sc", out)


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("env", "all"):
        env()
    if which in ("mem", "all"):
        mem()
    if which in ("sc", "all"):
        sc()
    if which in ("e1", "e2", "e3", "e4", "e5", "all"):
        ctx = Ctx()
        for name, fn in (("e1", e1), ("e2", e2), ("e3", e3), ("e4", e4), ("e5", e5)):
            if which in (name, "all"):
                t0 = time.time()
                fn(ctx)
                print(f"{name} done in {time.time()-t0:.0f}s")
