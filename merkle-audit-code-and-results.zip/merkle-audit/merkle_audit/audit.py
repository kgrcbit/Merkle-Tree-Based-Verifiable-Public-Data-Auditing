"""Roles of the protocol: data owner (commit), cloud-side prover, and public auditor."""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field

from .merkle import MerkleTree, Proof, content_digest, leaf_hash, root_from_proof
from .storage import ObjectStore

INTACT, MODIFIED, MISSING = "INTACT", "MODIFIED", "MISSING"


# ----------------------------------------------------------------------------- owner
@dataclass
class Commitment:
    keys: list[str]
    tree: MerkleTree
    t_fetch: float
    t_hash: float
    t_build: float

    @property
    def root(self) -> bytes:
        return self.tree.root

    def metadata_bytes(self) -> int:
        """Off-chain tree metadata: object keys + every node hash (32 B)."""
        return sum(len(k.encode()) for k in self.keys) + 32 * self.tree.node_count()


def build_commitment(store: ObjectStore, bucket: str, keys: list[str] | None = None,
                     contents: dict[str, bytes] | None = None) -> Commitment:
    """Owner side: hash every object, build the tree. If `contents` is given the owner hashes
    its local copy (upload path); otherwise objects are read back from the store."""
    keys = sorted(keys if keys is not None else store.list_keys(bucket))
    t_fetch = t_hash = 0.0
    leaves = []
    for k in keys:
        t0 = time.perf_counter()
        data = contents[k] if contents is not None else store.get(bucket, k)
        t1 = time.perf_counter()
        leaves.append(leaf_hash(k, content_digest(data)))
        t2 = time.perf_counter()
        t_fetch += t1 - t0
        t_hash += t2 - t1
    t0 = time.perf_counter()
    tree = MerkleTree(leaves)
    t_build = time.perf_counter() - t0
    return Commitment(keys, tree, t_fetch, t_hash, t_build)


# ----------------------------------------------------------------------------- prover
class Prover:
    """Cloud-side service holding the (untrusted) off-chain tree metadata."""

    def __init__(self, commitment: Commitment):
        self.c = commitment
        self.t_proofgen = 0.0

    def challenge(self, index: int) -> tuple[str, Proof]:
        t0 = time.perf_counter()
        p = self.c.tree.proof(index)
        self.t_proofgen += time.perf_counter() - t0
        return self.c.keys[index], p


# ----------------------------------------------------------------------------- auditor
@dataclass
class AuditReport:
    checked: int = 0
    status: dict[str, str] = field(default_factory=dict)
    bytes_objects: int = 0
    bytes_proofs: int = 0
    t_chain: float = 0.0
    t_fetch: float = 0.0
    t_hash: float = 0.0
    t_proofgen: float = 0.0
    t_verify: float = 0.0
    t_total: float = 0.0

    @property
    def failed(self) -> list[str]:
        return [k for k, s in self.status.items() if s != INTACT]

    def count(self, s: str) -> int:
        return sum(1 for v in self.status.values() if v == s)

    @property
    def passed(self) -> bool:
        return not self.failed


def proof_audit(store: ObjectStore, bucket: str, prover: Prover, trusted_root: bytes,
                n: int, indices: list[int], t_chain: float = 0.0) -> AuditReport:
    """Auditor side: for every challenged index fetch the object itself, recompute its leaf,
    obtain the sibling path from the prover and rebuild the root."""
    rep = AuditReport(t_chain=t_chain)
    prover.t_proofgen = 0.0
    t_start = time.perf_counter()
    for i in indices:
        key, proof = prover.challenge(i)
        rep.bytes_proofs += proof.size_bytes() + len(key.encode())
        t0 = time.perf_counter()
        data = store.get(bucket, key)
        t1 = time.perf_counter()
        rep.t_fetch += t1 - t0
        if data is None:
            rep.status[key] = MISSING
            continue
        rep.bytes_objects += len(data)
        leaf = leaf_hash(key, content_digest(data))
        t2 = time.perf_counter()
        computed = root_from_proof(leaf, proof)
        t3 = time.perf_counter()
        rep.t_hash += t2 - t1
        rep.t_verify += t3 - t2
        rep.status[key] = INTACT if computed == trusted_root else MODIFIED
    rep.checked = len(indices)
    rep.t_proofgen = prover.t_proofgen
    rep.t_total = (time.perf_counter() - t_start) + t_chain
    return rep


def sample_indices(n: int, c: int, rng: random.Random) -> list[int]:
    return sorted(rng.sample(range(n), min(c, n)))


def full_root_audit(store: ObjectStore, bucket: str, keys: list[str], trusted_root: bytes):
    """Dataset-level check: rebuild the whole root from current objects and compare once.
    Missing objects are reported and make the check fail (no leaf can be formed)."""
    t0 = time.perf_counter()
    leaves, missing, nbytes = [], [], 0
    for k in keys:
        d = store.get(bucket, k)
        if d is None:
            missing.append(k)
            continue
        nbytes += len(d)
        leaves.append(leaf_hash(k, content_digest(d)))
    root = MerkleTree(leaves).root if leaves else b""
    ok = (not missing) and root == trusted_root
    return ok, root, missing, nbytes, time.perf_counter() - t0


def full_data_baseline(store: ObjectStore, bucket: str, keys: list[str], local_digests: dict[str, bytes]):
    """Traditional full-data audit: download every object and compare its SHA-256 with a
    digest list the auditor keeps locally (32 B per object)."""
    t0 = time.perf_counter()
    status, nbytes, t_fetch, t_hash = {}, 0, 0.0, 0.0
    for k in keys:
        a = time.perf_counter()
        d = store.get(bucket, k)
        b = time.perf_counter()
        t_fetch += b - a
        if d is None:
            status[k] = MISSING
            continue
        nbytes += len(d)
        status[k] = INTACT if content_digest(d) == local_digests[k] else MODIFIED
        t_hash += time.perf_counter() - b
    return status, nbytes, t_fetch, t_hash, time.perf_counter() - t0
