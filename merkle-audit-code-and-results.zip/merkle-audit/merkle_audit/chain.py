"""Web3.py interface to the MerkleAuditRegistry contract on a local Hardhat (EVM) node."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass

from web3 import Web3

BUILD = os.path.join(os.path.dirname(__file__), "..", "chain", "build.json")


@dataclass
class TxResult:
    gas_used: int
    latency_s: float     # submit -> receipt (automining local node)
    block: int
    calldata_bytes: int


class Registry:
    def __init__(self, url: str = "http://127.0.0.1:8545"):
        self.w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 120}))
        assert self.w3.is_connected(), "Ethereum node not reachable"
        with open(BUILD) as f:
            self.build = json.load(f)
        self.owner = self.w3.eth.accounts[0]
        self.auditor = self.w3.eth.accounts[1]
        self.contract = None
        self.deploy_result: TxResult | None = None

    def _send(self, fn, sender) -> TxResult:
        tx = fn.build_transaction({"from": sender})
        t0 = time.perf_counter()
        h = self.w3.eth.send_transaction(tx)
        rc = self.w3.eth.wait_for_transaction_receipt(h)
        dt = time.perf_counter() - t0
        assert rc.status == 1, "transaction reverted"
        data = tx["data"]
        nbytes = (len(data) - 2) // 2 if isinstance(data, str) else len(data)
        return TxResult(rc.gasUsed, dt, rc.blockNumber, nbytes)

    def deploy(self, name: str = "MerkleAuditRegistry"):
        art = self.build[name]
        c = self.w3.eth.contract(abi=art["abi"], bytecode=art["bytecode"])
        t0 = time.perf_counter()
        h = c.constructor().transact({"from": self.owner})
        rc = self.w3.eth.wait_for_transaction_receipt(h)
        dt = time.perf_counter() - t0
        inst = self.w3.eth.contract(address=rc.contractAddress, abi=art["abi"])
        res = TxResult(rc.gasUsed, dt, rc.blockNumber, (len(art["bytecode"]) - 2) // 2)
        if name == "MerkleAuditRegistry":
            self.contract, self.deploy_result = inst, res
        return inst, res

    @staticmethod
    def dataset_id(name: str) -> bytes:
        return Web3.keccak(text=name)

    def register_root(self, ds: bytes, root: bytes, n: int) -> TxResult:
        return self._send(self.contract.functions.registerRoot(ds, root, n), self.owner)

    def get_root(self, ds: bytes):
        t0 = time.perf_counter()
        root, n, ts, ver, owner = self.contract.functions.getRoot(ds).call()
        return bytes(root), n, ver, time.perf_counter() - t0

    def get_root_gas(self, ds: bytes) -> int:
        return self.contract.functions.getRoot(ds).estimate_gas({"from": self.auditor})

    def record_audit(self, ds: bytes, checked: int, failed: int) -> TxResult:
        return self._send(self.contract.functions.recordAudit(ds, checked, failed), self.auditor)

    def verify_onchain(self, ds: bytes, leaf: bytes, siblings: list[bytes], mask: int):
        fn = self.contract.functions.verifyProof(ds, leaf, siblings, mask)
        t0 = time.perf_counter()
        ok = fn.call()
        dt = time.perf_counter() - t0
        gas = fn.estimate_gas({"from": self.auditor})
        return ok, gas, dt
