"""Binary SHA-256 Merkle tree used for object-storage integrity commitments.

Node definitions (domain-separated, RFC 6962 style):
    content digest   H_i  = SHA256(D_i)
    leaf node        L_i  = SHA256(0x00 || SHA256(k_i) || H_i)        (binds object key and content)
    internal node    P    = SHA256(0x01 || left || right)
Leaves are ordered by object key (lexicographic). An unpaired node at the end of a
level is promoted unchanged to the next level (no duplication).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

LEAF_PREFIX = b"\x00"
NODE_PREFIX = b"\x01"


def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def content_digest(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def leaf_hash(key: str, digest: bytes) -> bytes:
    return sha256(LEAF_PREFIX + sha256(key.encode("utf-8")) + digest)


def node_hash(left: bytes, right: bytes) -> bytes:
    return sha256(NODE_PREFIX + left + right)


@dataclass
class Proof:
    index: int
    siblings: list[bytes]   # from leaf level upwards
    left_mask: int          # bit j set => siblings[j] is the LEFT operand at step j

    def size_bytes(self) -> int:
        # 32 bytes per sibling + 32-byte direction bitmap (as passed to the contract)
        return 32 * len(self.siblings) + 32


class MerkleTree:
    def __init__(self, leaves: list[bytes]):
        if not leaves:
            raise ValueError("empty tree")
        self.levels: list[list[bytes]] = [list(leaves)]
        cur = self.levels[0]
        while len(cur) > 1:
            nxt = [node_hash(cur[i], cur[i + 1]) for i in range(0, len(cur) - 1, 2)]
            if len(cur) % 2 == 1:
                nxt.append(cur[-1])          # promote unpaired node
            self.levels.append(nxt)
            cur = nxt

    @property
    def root(self) -> bytes:
        return self.levels[-1][0]

    @property
    def n(self) -> int:
        return len(self.levels[0])

    def node_count(self) -> int:
        return sum(len(l) for l in self.levels)

    def proof(self, index: int) -> Proof:
        sibs: list[bytes] = []
        mask = 0
        idx = index
        for level in self.levels[:-1]:
            if idx % 2 == 1:                      # right child: sibling on the left
                mask |= 1 << len(sibs)
                sibs.append(level[idx - 1])
            elif idx + 1 < len(level):            # left child with a right sibling
                sibs.append(level[idx + 1])
            # else: promoted node, no sibling at this level
            idx //= 2
        return Proof(index, sibs, mask)


def root_from_proof(leaf: bytes, proof: Proof) -> bytes:
    h = leaf
    for j, s in enumerate(proof.siblings):
        h = node_hash(s, h) if (proof.left_mask >> j) & 1 else node_hash(h, s)
    return h


def verify(leaf: bytes, proof: Proof, trusted_root: bytes) -> bool:
    return root_from_proof(leaf, proof) == trusted_root
