"""Thin wrapper over an S3-compatible object store (MinIO Python SDK client)."""
from __future__ import annotations

import io

from minio import Minio
from minio.error import S3Error


class ObjectStore:
    def __init__(self, endpoint="127.0.0.1:9000", access="audit", secret="audit-secret-key"):
        self.c = Minio(endpoint, access_key=access, secret_key=secret, secure=False)

    def reset_bucket(self, bucket: str):
        if self.c.bucket_exists(bucket):
            for o in self.c.list_objects(bucket, recursive=False):
                self.c.remove_object(bucket, o.object_name)
        else:
            self.c.make_bucket(bucket)

    def put(self, bucket: str, key: str, data: bytes):
        self.c.put_object(bucket, key, io.BytesIO(data), len(data))

    def get(self, bucket: str, key: str) -> bytes | None:
        """Return object bytes, or None if the object does not exist."""
        try:
            r = self.c.get_object(bucket, key)
            try:
                return r.read()
            finally:
                r.close()
                r.release_conn()
        except S3Error as e:
            if e.code in ("NoSuchKey", "NoSuchObject"):
                return None
            raise

    def delete(self, bucket: str, key: str):
        self.c.remove_object(bucket, key)

    def list_keys(self, bucket: str) -> list[str]:
        # flat key namespace (no '/'); non-recursive listing with '/' delimiter returns every key
        return sorted(o.object_name for o in self.c.list_objects(bucket, recursive=False))
