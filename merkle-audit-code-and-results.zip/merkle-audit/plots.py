"""Generates every figure (PDF) and the summary used for the paper from results/*.json."""
import json
import os
import statistics as st

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = "results"
F = "figures"
os.makedirs(F, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#4a3aa7"
INK, MUTED = "#0b0b0b", "#52514e"

plt.rcParams.update({
    "font.family": "serif", "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.edgecolor": MUTED, "axes.linewidth": 0.6,
    "axes.grid": True, "grid.color": "#e4e3df", "grid.linewidth": 0.5, "lines.linewidth": 1.4,
    "lines.markersize": 4, "legend.frameon": False, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
W1 = 3.45   # IEEE single column width (in)


def load(n):
    with open(os.path.join(R, f"{n}.json")) as f:
        return json.load(f)


def ms(x):
    return 1000 * x


def mean(xs):
    return st.mean(xs)


def sd(xs):
    return st.stdev(xs) if len(xs) > 1 else 0


# ------------------------------------------------------------ Fig: affected objects vs audit time (E3 + E4)
def fig_tamper_delete():
    e3, e4 = load("e3"), load("e4")
    fig, ax = plt.subplots(figsize=(W1, 1.9))
    t3 = sorted(int(k) for k in e3["levels"])
    y3 = [[r["t_total"] for r in e3["levels"][str(t)]["runs"]] for t in t3]
    ax.errorbar(t3, [mean(v) for v in y3], yerr=[sd(v) for v in y3], color=BLUE, marker="o",
                capsize=2, label="modified objects (E3)")
    t4 = sorted(int(k) for k in e4["levels"])
    y4 = [[r["t_total"] for r in e4["levels"][str(t)]] for t in t4]
    ax.errorbar(t4, [mean(v) for v in y4], yerr=[sd(v) for v in y4], color=ORANGE, marker="s",
                capsize=2, label="deleted objects (E4)")
    ax.set_xscale("symlog", linthresh=1)
    ax.set_xticks([1, 5, 10, 25, 50, 100, 250])
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.set_xlabel("Number of affected objects (of $n$ = 1,000)")
    ax.set_ylabel("Full audit time (s)")
    lo = min(min(mean(v) for v in y3), min(mean(v) for v in y4))
    hi = max(max(mean(v) for v in y3), max(mean(v) for v in y4))
    ax.set_ylim(0, hi * 1.25)
    ax.legend(loc="lower left")
    fig.savefig(f"{F}/fig_affected_vs_time.pdf")
    plt.close(fig)


# ------------------------------------------------------------ Fig: sampled audit detection probability
def fig_sampling():
    e3 = load("e3")
    fig, ax = plt.subplots(figsize=(W1, 2.0))
    cols = [BLUE, ORANGE, AQUA, VIOLET]
    marks = ["o", "s", "^", "D"]
    for c, col, mk in zip(e3["samples"], cols, marks):
        ts = sorted(int(k) for k in e3["levels"])
        emp = [mean(r["mc_detect"][str(c)] for r in e3["levels"][str(t)]["runs"]) for t in ts]
        ana = [e3["levels"][str(t)]["analytic"][str(c)] for t in ts]
        ax.plot(ts, ana, color=col, lw=1.0, ls="--")
        ax.plot(ts, emp, color=col, marker=mk, lw=0, label=f"$c$ = {c}")
    ax.set_xscale("log")
    ax.set_xticks([1, 5, 10, 25, 50, 100, 250])
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.set_xlabel("Number of modified objects $t$ (of $n$ = 1,000)")
    ax.set_ylabel("Detection probability")
    ax.set_ylim(-0.03, 1.05)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=4, columnspacing=1.0, handletextpad=0.3,
              title="markers: measured (Monte Carlo); dashed: analytic", title_fontsize=6.5)
    fig.savefig(f"{F}/fig_sampling.pdf")
    plt.close(fig)


# ------------------------------------------------------------ Fig: scalability (construction + verification)
def fig_scal_build():
    mem, e5 = load("mem"), load("e5")
    ns = sorted(int(k) for k in mem)
    fig, ax = plt.subplots(figsize=(W1, 2.0))
    ax.errorbar(ns, [ms(mem[str(n)]["build"]["mean"]) for n in ns],
                yerr=[ms(mem[str(n)]["build"]["std"]) for n in ns], color=BLUE, marker="o", capsize=2,
                label="tree construction, in-memory leaves")
    n5 = sorted(int(k) for k in e5)
    ax.errorbar(n5, [ms(mean(c["t_build"] for c in e5[str(n)]["commits"])) for n in n5],
                yerr=[ms(sd([c["t_build"] for c in e5[str(n)]["commits"]])) for n in n5],
                color=ORANGE, marker="s", capsize=2, label="tree construction, S3 datasets")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Number of objects $n$")
    ax.set_ylabel("Construction time (ms)")
    ax.legend(loc="upper left")
    fig.savefig(f"{F}/fig_build.pdf")
    plt.close(fig)


def fig_scal_audit():
    e5 = load("e5")
    ns = sorted(int(k) for k in e5)
    fig, ax = plt.subplots(figsize=(W1, 2.15))
    series = [
        ("full-data baseline (download + hash all)", lambda d: [b["t_total"] for b in d["baseline"]], INK, "x", ":"),
        ("Merkle full audit ($n$ proofs)", lambda d: [a["t_total"] for a in d["audits"]], BLUE, "o", "-"),
        ("Merkle sampled audit ($c$ = 100)", lambda d: [a["t_total"] for a in d["sampled"]], ORANGE, "s", "-"),
        ("Merkle single-object audit", lambda d: [a["t_total"] for a in d["single"]], AQUA, "^", "-"),
    ]
    for lab, f, col, mk, ls in series:
        ys = [f(e5[str(n)]) for n in ns]
        ax.errorbar(ns, [ms(mean(v)) for v in ys], yerr=[ms(sd(v)) for v in ys], color=col, marker=mk,
                    ls=ls, capsize=2, label=lab)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Number of objects $n$")
    ax.set_ylabel("Audit time (ms)")
    ax.legend(loc="upper left", fontsize=6.5)
    fig.savefig(f"{F}/fig_audit_time.pdf")
    plt.close(fig)


def fig_scal_verify():
    mem = load("mem")
    ns = sorted(int(k) for k in mem)
    fig, ax = plt.subplots(figsize=(W1, 1.9))
    ax.errorbar(ns, [1e6 * mem[str(n)]["verify"]["mean"] for n in ns],
                yerr=[1e6 * mem[str(n)]["verify"]["std"] for n in ns], color=BLUE, marker="o", capsize=2,
                label="proof verification")
    ax.errorbar(ns, [1e6 * mem[str(n)]["proofgen"]["mean"] for n in ns],
                yerr=[1e6 * mem[str(n)]["proofgen"]["std"] for n in ns], color=ORANGE, marker="s", capsize=2,
                label="proof generation")
    ax.set_xscale("log")
    ax.set_xlabel("Number of objects $n$")
    ax.set_ylabel("Time per proof ($\\mu$s)")
    ax2 = ax.twiny() if False else None
    for n in ns:
        pass
    ax.legend(loc="upper left")
    fig.savefig(f"{F}/fig_verify.pdf")
    plt.close(fig)


# ------------------------------------------------------------ Fig: communication
def fig_comm():
    e5 = load("e5")
    ns = sorted(int(k) for k in e5)
    fig, ax = plt.subplots(figsize=(W1, 2.0))
    base = [mean(b["bytes"] for b in e5[str(n)]["baseline"]) for n in ns]
    samp = [mean(a["bytes_objects"] + a["bytes_proofs"] for a in e5[str(n)]["sampled"]) for n in ns]
    one = [mean(a["bytes_objects"] + a["bytes_proofs"] for a in e5[str(n)]["single"]) for n in ns]
    prf = [mean(a["bytes_proofs"] for a in e5[str(n)]["single"]) for n in ns]
    for ys, lab, col, mk, ls in [(base, "full-data baseline", INK, "x", ":"),
                                 (samp, "Merkle sampled audit ($c$ = 100)", ORANGE, "s", "-"),
                                 (one, "Merkle single-object audit", AQUA, "^", "-"),
                                 (prf, "proof metadata only (single object)", VIOLET, "D", "--")]:
        ax.plot(ns, [y / 1024 for y in ys], color=col, marker=mk, ls=ls, label=lab)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Number of objects $n$")
    ax.set_ylabel("Data transferred per audit (KiB)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=2, fontsize=6.5, columnspacing=1.0)
    fig.savefig(f"{F}/fig_comm.pdf")
    plt.close(fig)


# ------------------------------------------------------------ Fig: on-chain gas
def fig_gas():
    sc = load("sc")
    fig, ax = plt.subplots(figsize=(W1, 1.9))
    ns = sorted(int(k) for k in sc["baseline"])
    ax.plot(ns, [sc["baseline"][str(n)]["gas"] for n in ns], color=INK, marker="x", ls=":",
            label="every object digest on-chain")
    rf = mean(r["gas_used"] for r in sc["register_first"])
    ax.plot(ns, [rf] * len(ns), color=BLUE, marker="o", label="single Merkle root (registerRoot)")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("Number of objects $n$")
    ax.set_ylabel("Gas to commit dataset")
    ax.legend(loc="upper left")
    fig.savefig(f"{F}/fig_gas.pdf")
    plt.close(fig)


if __name__ == "__main__":
    for f in (fig_tamper_delete, fig_sampling, fig_scal_build, fig_scal_audit, fig_scal_verify, fig_comm, fig_gas):
        try:
            f(); print("ok", f.__name__)
        except FileNotFoundError as e:
            print("skip", f.__name__, e)
