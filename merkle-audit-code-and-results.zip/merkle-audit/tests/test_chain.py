import os
from merkle_audit.chain import Registry
from merkle_audit.merkle import MerkleTree, leaf_hash, content_digest

def test_onchain_matches_offchain():
    r = Registry(); r.deploy()
    for n in (1, 2, 3, 7, 33):
        L = [leaf_hash(f"k{i}", content_digest(os.urandom(16))) for i in range(n)]
        t = MerkleTree(L); ds = r.dataset_id(f"t{n}")
        r.register_root(ds, t.root, n)
        root, cnt, ver, _ = r.get_root(ds)
        assert root == t.root and cnt == n
        for i in range(n):
            p = t.proof(i)
            ok, gas, _ = r.verify_onchain(ds, L[i], p.siblings, p.left_mask)
            assert ok
        p = t.proof(0)
        ok, _, _ = r.verify_onchain(ds, os.urandom(32), p.siblings, p.left_mask)
        assert not ok
    rc = r.record_audit(ds, 33, 0)
    assert r.contract.functions.auditCount(ds).call() == 1
