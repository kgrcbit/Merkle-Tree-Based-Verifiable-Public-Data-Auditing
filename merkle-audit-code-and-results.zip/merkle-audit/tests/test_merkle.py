import os, random
from merkle_audit.merkle import MerkleTree, leaf_hash, content_digest, verify, root_from_proof, node_hash

def leaves(n):
    return [leaf_hash(f"obj-{i:06d}", content_digest(os.urandom(64))) for i in range(n)]

def test_all_proofs_verify_for_many_sizes():
    for n in list(range(1, 70)) + [127, 128, 129, 1000]:
        L = leaves(n); t = MerkleTree(L)
        for i in range(n):
            p = t.proof(i)
            assert verify(L[i], p, t.root)
            assert len(p.siblings) <= max(0, (n - 1).bit_length())

def test_modified_leaf_fails_everywhere():
    L = leaves(37); t = MerkleTree(L)
    for i in range(37):
        bad = leaf_hash(f"obj-{i:06d}", content_digest(b"tampered"))
        assert not verify(bad, t.proof(i), t.root)

def test_key_binding_swap_detected():
    d = content_digest(b"x")
    assert leaf_hash("a", d) != leaf_hash("b", d)

def test_promotion_odd_level():
    L = leaves(3); t = MerkleTree(L)
    assert t.root == node_hash(node_hash(L[0], L[1]), L[2])

def test_wrong_sibling_fails():
    L = leaves(16); t = MerkleTree(L); p = t.proof(5)
    p.siblings[2] = os.urandom(32)
    assert not verify(L[5], p, t.root)
